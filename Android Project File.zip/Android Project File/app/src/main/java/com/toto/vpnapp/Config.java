package com.toto.vpnapp;

public class Config {



    public static final String all_month_id = "toto1";
    public static final String all_threemonths_id = "toto2";
    public static final String all_sixmonths_id = "toto3";
    public static final String all_yearly_id = "toto4";

    /*settings parameters (don't change them these are auto controlled by application flow)*/
    public static boolean ads_subscription = false;
    public static boolean vip_subscription = false;
    public static boolean all_subscription = false;
}
