package com.toto.vpnapp;


import android.app.Application;


public class App extends Application {


}
