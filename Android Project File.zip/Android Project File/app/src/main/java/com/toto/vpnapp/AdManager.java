package com.toto.vpnapp;

public class AdManager {

}